/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package control;

/**
 *
 * @author ntkhanh
 */

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.io.*;
import java.io.IOException;
import java.net.Socket;
import java.net.UnknownHostException;
import model.Student;
import model.*;
import view.Student2Teacher;

public class ClientStudent implements ActionListener{
	// khai bao socket cho client, luong vao-ra
	Socket mySocket = null;
	ObjectOutputStream os = null;
	ObjectInputStream is = null;
        Student2Teacher view;
        Student student;

    public ClientStudent(Student2Teacher view) {
        this.view = view;
        view.addActionListerner(this);
        view.setVisible(true);
    }
        
	// Tao ket noi
	public void connection(String ip) {
		try {
			mySocket = new Socket(ip, 9999);
			os = new ObjectOutputStream(mySocket.getOutputStream());
			is = new ObjectInputStream(mySocket.getInputStream());
		} catch (UnknownHostException e) {
			System.err.println(e);
		} catch (IOException e) {
			System.err.println(e);
		}
	}

	
        public void sendToTeacher(Student student) { // gui du lieu den server if (mySocket !=
									// null && os != null) {
		try {
			os.writeObject(student);
		} catch (UnknownHostException e) {
			e.printStackTrace();
		} catch (IOException e) {
			System.err.println(e);
		}
	}

	
        public Teacher receiveFromTeacher () throws ClassNotFoundException { // nhan du lieu tra ve tu server
		if (mySocket != null && is != null) {
			try {
                           return (Teacher) is.readObject();
				
			} catch (UnknownHostException e) {
				System.err.println(e);
			} catch (IOException e) {
				System.err.println(e);
			}
		}
		return null;
	}

	// dong cac ket noi
	public void close() {
		if (mySocket != null && os != null && is != null) {
			try {
				os.close();
				is.close();
				mySocket.close();
			} catch (UnknownHostException e) {
				System.err.println(e);
			} catch (IOException e) {
				System.err.println(e);
			}
		}
	}

    @Override
    public void actionPerformed(ActionEvent e) {
        if(!(view.getCode().equals(null) || view.getName().equals(null)||view.getTeacherIP().equals(null))){
            this.student = new Student(view.getCode(), view.getName(), "localhost", view.getMessage());
           this.connection(view.getTeacherIP());
           this.sendToTeacher(this.student);
        }
        
          
           /*this.sendToStudent(teacher);
            try {
               Student sv =  this.receiveFromStudent();
               JOptionPane.showMessageDialog(null,"Get response from " + sv.getHovaten() + " - "+
                       sv.getMaSV()+ " at " + sv.getIP());
            } catch (ClassNotFoundException ex) {
                Logger.getLogger(ClientTeacher.class.getName()).log(Level.SEVERE, null, ex);
            }*/
    }

	
}

