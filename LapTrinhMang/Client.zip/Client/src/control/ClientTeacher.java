/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package control;

/**
 *
 * @author ntkhanh
 */

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.io.*;
import java.io.IOException;
import java.net.Inet4Address;
import java.net.InetAddress;
import java.net.Socket;
import java.net.UnknownHostException;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.swing.JOptionPane;
import model.Student;
import model.Teacher;
import view.Teacher2Student;

public class ClientTeacher implements ActionListener{
	// khai bao socket cho client, luong vao-ra
	Socket mySocket = null;
	ObjectOutputStream os;
	ObjectInputStream is;
        Teacher2Student view;
        Teacher teacher;

    public ClientTeacher(Teacher2Student view) {
        this.view = view;
        this.view.changeActionListener(this);
        this.view.setVisible(true);
    }
        
	// Tao ket noi
	public void connection(String ip) {
		try {
			mySocket = new Socket(ip, 9998);
			os = new ObjectOutputStream(mySocket.getOutputStream());
			is = new ObjectInputStream(mySocket.getInputStream());
                        this.teacher = view.getTeacher();
                        this.sendToStudent(teacher);
		} catch (UnknownHostException e) {
			e.printStackTrace();
                         this.close();
		} catch (IOException e) {
			e.printStackTrace();
                         this.close();
		}
	}

	public void sendToStudent(Teacher teacher) { // gui du lieu den server if (mySocket !=
									// null && os != null) {
		try {
			os.writeObject(teacher);
		} catch (UnknownHostException e) {
			e.printStackTrace();
                        this.close();
		} catch (IOException e) {
			e.printStackTrace();
                         this.close();
		}
	}

	public Student receiveFromStudent () throws ClassNotFoundException { // nhan du lieu tra ve tu server
		if (mySocket != null && is != null) {
			try {
                            return (Student) is.readObject();
				
			} catch (UnknownHostException e) {
				System.err.println(e);
			} catch (IOException e) {
				System.err.println(e);
			}
		}
		return null;
	}

	// dong cac ket noi
	public void close() {
		if (mySocket != null && os != null && is != null) {
			try {
				os.close();
				is.close();
				mySocket.close();
			} catch (UnknownHostException e) {
				System.err.println(e);
			} catch (IOException e) {
				System.err.println(e);
			}
		}
	}

    @Override
    public void actionPerformed(ActionEvent e) {
            System.out.println(e.getActionCommand());
           if(e.getActionCommand().toString().equalsIgnoreCase("connect")){
                this.connection(view.getIP());
                view.enableSendButton();
                
           }else if(e.getActionCommand().toString().equalsIgnoreCase("send")){
                this.teacher = view.getTeacher();
                this.sendToStudent(teacher);
           }
          
           /* try {
               Student sv =  this.receiveFromStudent();
               JOptionPane.showMessageDialog(null,"Get response from " + sv.getHovaten() + " - "+
                       sv.getMaSV()+ " at " + sv.getIP());
            } catch (ClassNotFoundException ex) {
                Logger.getLogger(ClientTeacher.class.getName()).log(Level.SEVERE, null, ex);
            } */
    }

	
}

