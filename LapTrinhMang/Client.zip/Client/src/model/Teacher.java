/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package model;

import java.io.Serializable;

/**
 *
 * @author ntkhanh
 */
public class Teacher implements Serializable{
   static final long serialVersionUID = 2L;
    private String hovaten;
    private String message;

    public String getHovaten() {
        return hovaten;
    }

    public String getMessage() {
        return message;
    }

    public Teacher(String hovaten, String message) {
        this.hovaten = hovaten;
        this.message = message;
    }

    public void setHovaten(String hovaten) {
        this.hovaten = hovaten;
    }

    public void setMessage(String message) {
        this.message = message;
    }
    
}
