/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package client;

import control.ClientStudent;
import control.ClientTeacher;
import view.Student2Teacher;
import view.Teacher2Student;

/**
 *
 * @author ntkhanh
 */
public class Test {
    public static void main(String[] args) {
     //Student2Teacher view = new Student2Teacher();
     //ClientStudent clientControl = new ClientStudent(view);
        Teacher2Student view = new Teacher2Student();
        ClientTeacher clientControl = new ClientTeacher(view);
    }
    
    
}
