/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package rmiserver_class;

import control.IRegistration;
import control.Registration;
import java.rmi.RemoteException;
import view.ClientList;

/**
 *
 * @author ntkhanh
 */
public class RMIServer_Class {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) throws RemoteException {
        // TODO code application logic here
        ClientList view  = new ClientList();
        IRegistration reg = new Registration(view);
    }
    
}
