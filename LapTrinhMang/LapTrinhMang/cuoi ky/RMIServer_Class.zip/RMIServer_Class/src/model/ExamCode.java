/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package model;

/**
 *
 * @author ntkhanh
 */
public class ExamCode {

    //String exam
    public static final String ALPHA_STRING = "AaBbCcDdEeFfGgHhIiJjKkLlMmNnOoPpQqRrSsTtUuVvWwXxYyZ";
    public static final String NUMERIC_STRING = "0123456789";
    public static final String SPECIAL_STRING = "~!@#$%^&*()><-`/";
    public static final int NUMCHAROFSTRING = 1;
    public static final int REVERSESTRING = 2;
    public static final int UPPERLOWER = 3;
    public static final int NUMSPECIALCHAR = 4;
    public static final int STRING2NUMERIC = 5;
    public static final int UNIQUECHARACTER=6;
    public static final int COUNTSUBSTRING=7;

}
