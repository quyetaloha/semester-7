﻿- 5 file ACT_ là 5 biểu đồ hoạt động
- Biểu đồ tuần tự trong file sequence.vpp nha ( tớ gộp 3 cái biểu đồ vào file đó luôn nên lát c xem tớ chỉ c mở )
- Biểu đồ Usecase trong mấy file UC_ nha
- Kịch bản tớ cũng viết trong file UC_ luôn ý.
- Còn cái phác họa giao diện tớ chưa làm ế @@ để tối tớ hóng các bạn.
- Còn code là file baiTest1 tớ code theo ví dụ thầy gửi mỗi cái database là file thoai ^^.
<3